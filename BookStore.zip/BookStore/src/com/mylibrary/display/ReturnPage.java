package com.mylibrary.display;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.mylibrary.db.ActivityLog;
import com.mylibrary.ops.Book;
import com.mylibrary.ops.Student;

public class ReturnPage extends HttpServlet { 

private static final long serialVersionUID = 1L; 

public ReturnPage() { 
	super(); 
}

protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException { 

Object obj = request.getServletContext().getAttribute("user"); 

PrintWriter out = response.getWriter(); 

if(obj != null) 

{ 

Student std = (Student) obj;  {
	String bid = request.getParameter("bid"); 
   if(bid!=null) 

	{ 

	UpdateBook.returnBook(Integer.parseInt(bid));
	ActivityLog.returnActivity(std.getSid(), Integer.parseInt(bid)); 

	} 

	ArrayList<ActivityLog> activities = ActivityLog.getReturnedLogs(std.getSid()); 
     request.getRequestDispatcher("header.html").include(request, response); 

	 

	request.getRequestDispatcher("navigation.html").include(request, response); 

	 

	 

	System.out.println("<div class=\"container-fluid row\" style=\"background-image: url('./images/issue.jpg'); background-size: cover;\">\r\n" + 

	"<div class=\"container col-lg-12row\">\r\n" + "<div class=\"jumbotron col-lg-12 mt-4 text-center text-success\">\r\n" + 

	 

	"<h3>Returned Books</h3>\r\n" + "	</div>\r\n" + "	</div>\r\n" + "\r\n" + "<div class=\"container\">\r\n" + "<table class=\"table table-light\">\r\n" + "<thead>\r\n" + "	<tr>\r\n" + 

	"	<th scope=\"col\">#</th>\r\n" + "<th scope=\"col\">Book Name</th>\r\n" + "	<th scope=\"col\">Book Author</th>\r\n" + "	<th scope=\"col\">Price</th>\r\n" + 

	"<th scope=\"col\">Date</th>\r\n" +			"</tr>\r\n" + "</thead>\r\n" + 

			"<tbody>"); 

			 

			 

			if(!activities.isEmpty()) 

			{ 

			for(int i = 0 ; i < activities.size(); i++) 

			{ 

			Book book = RetrieveBook.getBook(activities.get(i).getBid()); 
			System.out.println("<tr>\r\n" + "<th scope=\"row\">"+ (i+1) +"</th>\r\n" +"<td>"+ book.getBname()+"</td>\r\n" + "<td>"+"book.getBauthor()"+"</td>\r\n" + "	<td>"+ 
            book.getBprice()+"</td>\r\n" + "	<td>"+ activities.get(i).getDate()+"</td>\r\n" +"	</tr>"); 
			} 
			} 
			else { 
            System.out.println("<tr><td colspan=\"5\"> NO ANY BOOK IS RETURNED"+"</td></tr>"); 
               } 

			System.out.println("</tbody>\r\n" + "</table>\r\n" + "</div>\r\n" + "</div>"); 
            request.getRequestDispatcher("footer.html").include(request, response); 

}
}
else 

   { 
    response.sendRedirect("index"); 
     } 
   }

protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException { 

// TODO Auto-generated method stub
	doGet(request, response); 



	 
}

}
