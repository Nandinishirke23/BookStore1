package com.mylibrary.ops;

import java.sql.Date;

public class Activity {
	private int aid;
	private int sid;
	private int bid;
	private Date date;
	private String status;
	public Activity(int aid, int sid, int bid, Date date, String status) {
		super();
		this.aid = aid;
		this.sid = sid;
		this.bid = bid;
		this.date = date;
		this.status = status;
	}
	public int getAid() {
		return aid;
	}
	public void setAid(int aid) {
		this.aid = aid;
	}
	public int getSid() {
		return sid;
	}
	public void setSid(int sid) {
		this.sid = sid;
	}
	public int getBid() {
		return bid;
	}
	public void setBid(int bid) {
		this.bid = bid;
	}
	public Date getDate() {
		return date;
	}
	public void setDate(Date date) {
		this.date = date;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	@Override
	public String toString() {
		return "Activity [aid=" + aid + ", sid=" + sid + ", bid=" + bid + ", date=" + date + ", status=" + status + "]";
	}
	

}
