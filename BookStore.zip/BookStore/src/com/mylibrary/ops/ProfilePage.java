package com.mylibrary.ops;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class ProfilePage extends HttpServlet { 

private static final long serialVersionUID = 1L; 
public ProfilePage() { super(); 
} 

protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException { 

	Object obj = request.getServletContext().getAttribute("user"); response.setContentType("text/html"); 

	PrintWriter out = response.getWriter(); 
	if( obj!=null) 
     {  
		Student std = (Student) obj; 
	     request.getRequestDispatcher("header.html").include(request, response); 
	     request.getRequestDispatcher("navigation.html").include(request,response); 

	System.out.println("<div class=\"container-fluid row p-4\" style=\"background- image: url('./images/profile.jpg'); background-size: cover; background-position: 0px;\">\r\n" + "<div class=\"container col-lg-6\">\r\n" + "<table class=\"table table-hover table-dark\">\r\n" + "		<thead>\r\n" + 
    "<tr>\r\n" + "<th scope=\"col\">Logs</th>\r\n" + "<th scope=\"col\">Profile Details</th>\r\n" + "</tr>\r\n" + "</thead>\r\n" + "<tbody>\r\n" + "<tr>\r\n" + 
   "<td>Profile Name</td>\r\n" + "<td>" + std.getName() + "</td>\r\n" + "</tr>\r\n" + "<tr>\r\n" + "<td>Contact</td>\r\n" + "<td>" + std.getContact() + "</td>\r\n" + 
   "</tr>\r\n" + "<tr>\r\n" + "<td>Email Id</td>\r\n" + "<td>" + std.getEmail() + "</td>\r\n" + "</tr>\r\n" + "<tr>\r\n" + "<td>Student Id</td>\r\n" + "<td>" + std.getSid() + "</td>\r\n" + 
"</tr>\r\n" + "<tr>\r\n" + "<td>Age</td>\r\n" + "<td>" + std.getAge() + "</td>\r\n" + "</tr>\r\n" + "<tr>\r\n" + "<td>Address</td>\r\n" + "<td>" + std.getAddress() + "</td>\r\n" + "	</tr>\r\n" + "</tbody>\r\n" + "</table>\r\n" + "	</div>\r\n" + 
"<div class=\"container col-lg-6\">\r\n" + "<div class=\"jumbotron\">\r\n" + "<form action=\"search\">\r\n" + "<label for=\"search\">Check My Book</label>\r\n" + "<input type=\"text\" class=\"form-control\" name=\"search\" id=\"search\">\r\n" + 
"<input class=\"btn btn-primary mt-3\" type=\"submit\" value=\"search now\">\r\n" + "</form>\r\n" + "</div>\r\n" + 
"</div>\r\n" + " </div>"); 
	request.getRequestDispatcher("footer.html").include(request, response); 
     }  
	else 
	{ 
        response.sendRedirect("index"); 
       } 
      } 


	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException { 

		doGet(request, response); 

	} 
} 


