package com.mylibrary.ops;

public class Book {
	private int bid; private String bname; 

	private String bauthor; private double bprice; private String bgenre; private String status;

	public Book(int bid, String bname, String bauthor, double bprice, String bgenre, String status) {
		super();
		this.bid = bid;
		this.bname = bname;
		this.bauthor = bauthor;
		this.bprice = bprice;
		this.bgenre = bgenre;
		this.status = status;
	}

	public int getBid() {
		return bid;
	}

	public void setBid(int bid) {
		this.bid = bid;
	}

	public String getBname() {
		return bname;
	}

	public void setBname(String bname) {
		this.bname = bname;
	}

	public String getBauthor() {
		return bauthor;
	}

	public void setBauthor(String bauthor) {
		this.bauthor = bauthor;
	}

	public double getBprice() {
		return bprice;
	}

	public void setBprice(double bprice) {
		this.bprice = bprice;
	}

	public String getBgenre() {
		return bgenre;
	}

	public void setBgenre(String bgenre) {
		this.bgenre = bgenre;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status; 
	}

	public String getIssueStatus() 

	{ 

	if(this.status.equals("true")) 

	{ 

	return "<a class=\"text-danger\" >Issued</a>"; 

	} 

	else 

	{ 
		return "<a href=\"issue?bid="+ this.bid +"\" class=\"text-success\">Issue</a>"; 

				} 

				} 

     public String getReturnStatus() 

				{ 

  return "<a href=\"return?bid=" + this.bid + "\" class=\"text-danger\">Return</a>"; 

				} 
	@Override
	public String toString() {
		return "Book [bid=" + bid + ", bname=" + bname + ", bauthor=" + bauthor + ", bprice=" + bprice + ", bgenre="
				+ bgenre + ", status=" + status + "]";
	} 
	
}
