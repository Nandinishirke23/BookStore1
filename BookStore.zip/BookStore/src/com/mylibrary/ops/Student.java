package com.mylibrary.ops;

public class Student {
	private int sid; private String name; private long contact; private String email; 
	private int age; private int sClass; private String address; 

	private String password;

	public Student(int sid, String name, long contact, String email, int age, int sClass, String address,
			String password) {
		super();
		this.sid = sid;
		this.name = name;
		this.contact = contact;
		this.email = email;
		this.age = age;
		this.sClass = sClass;
		this.address = address;
		this.password = password;
	}

	public int getSid() {
		return sid;
	}

	public void setSid(int sid) {
		this.sid = sid;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public long getContact() {
		return contact;
	}

	public void setContact(long contact) {
		this.contact = contact;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	public int getsClass() {
		return sClass;
	}

	public void setsClass(int sClass) {
		this.sClass = sClass;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	@Override
	public String toString() {
		return "Student [sid=" + sid + ", name=" + name + ", contact=" + contact + ", email=" + email + ", age=" + age
				+ ", sClass=" + sClass + ", address=" + address + ", password=" + password + "]";
	}

	
}
